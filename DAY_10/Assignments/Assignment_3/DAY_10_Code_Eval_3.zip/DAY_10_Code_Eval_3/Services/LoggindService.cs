﻿using Serilog;

namespace DAY_10_Code_Eval_3.Services
{
    public static class LoggingService
    {
        public static void ConfigureLogger()
        {
            Log.Logger = new LoggerConfiguration()
                .WriteTo.File("logs/app-log.txt",
                rollingInterval:
                RollingInterval.Day)
                .CreateLogger();
        }
    }
}