﻿using System;
using System.Collections.Generic;
using DAY_10_Code_Eval_3.Models;
using DAY_10_Code_Eval_3.Utilities;
using Serilog;

namespace DAY_10_Code_Eval_3.Services
{
    public class AuthenticationService
    {
        private readonly List<User> users =
            new List<User>();

        private readonly EncryptionService
            encryptionService =
            new EncryptionService();

        public void Register(
            string username,
            string password,
            string details)
        {
            try
            {
                string hashedPassword =
                    PasswordHasher.HashPassword(password);

                string encryptedDetails =
                    encryptionService.Encrypt(details);

                User user = new User
                {
                    Username = username,
                    HashedPassword = hashedPassword,
                    EncryptedDetails = encryptedDetails
                };

                users.Add(user);

                Log.Information(
                    $"User registered: {username}");
            }
            catch (Exception ex)
            {
                Log.Error(
                    ex,
                    "Error during registration");
            }
        }

        public bool Login(
            string username,
            string password)
        {
            try
            {
                string hashedPassword =
                    PasswordHasher.HashPassword(password);

                foreach (User user in users)
                {
                    if (user.Username == username &&
                        user.HashedPassword ==
                        hashedPassword)
                    {
                        Log.Information(
                            $"User logged in: {username}");

                        return true;
                    }
                }

                Log.Warning(
                    $"Failed login attempt: {username}");

                return false;
            }
            catch (Exception ex)
            {
                Log.Error(
                    ex,
                    "Login error");

                return false;
            }
        }

        public string GetDecryptedDetails(
            string username)
        {
            foreach (User user in users)
            {
                if (user.Username == username)
                {
                    return encryptionService.Decrypt(
                        user.EncryptedDetails);
                }
            }

            return null;
        }
    }
}