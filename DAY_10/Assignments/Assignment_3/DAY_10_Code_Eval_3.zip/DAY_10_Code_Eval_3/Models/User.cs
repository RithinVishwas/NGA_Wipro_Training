﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAY_10_Code_Eval_3.Models
{
    public class User
    {
        public string Username { get; set; }

        public string HashedPassword { get; set; }

        public string EncryptedDetails { get; set; }
    }
}