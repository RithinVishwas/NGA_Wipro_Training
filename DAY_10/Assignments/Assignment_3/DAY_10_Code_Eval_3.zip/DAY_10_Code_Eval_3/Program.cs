﻿using System;
using DAY_10_Code_Eval_3.Services;

namespace DAY_10_Code_Eval_3
{
    class Program
    {
        static void Main(string[] args)
        {
            LoggingService.ConfigureLogger();

            AuthenticationService authService =
                new AuthenticationService();

            Console.WriteLine(
                "===== USER REGISTRATION =====");

            authService.Register(
                "Rithin",
                "Password123",
                "Sensitive User Details");

            Console.WriteLine(
                "User Registered Successfully");

            Console.WriteLine();

            Console.WriteLine(
                "===== USER LOGIN =====");

            bool loginSuccess =
                authService.Login(
                    "Rithin",
                    "Password123");

            Console.WriteLine(
                $"Login Success: {loginSuccess}");

            Console.WriteLine();

            Console.WriteLine(
                "===== DECRYPTED DATA =====");

            string details =
                authService.GetDecryptedDetails(
                    "Rithin");

            Console.WriteLine(details);

            Console.ReadLine();
        }
    }
}